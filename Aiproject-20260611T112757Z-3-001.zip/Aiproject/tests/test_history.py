import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_agents import run_history_agent

result = run_history_agent("P001")

print(result)