import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from langchain_agents import parallel_workflow, run_diagnosis_agent


inputs = {
    "patient_id": "P001",
    "patient_complaint": "I have chest pain, sweating, and shortness of breath."
}

parallel_result = parallel_workflow.invoke(inputs)

triage_output = parallel_result["triage"]
history_output = parallel_result["history"]

diagnosis_output = run_diagnosis_agent(
    patient_complaint=inputs["patient_complaint"],
    triage_output=triage_output,
    history_output=history_output
)

print("===== TRIAGE OUTPUT =====")
print(triage_output)

print("\n===== HISTORY OUTPUT =====")
print(history_output)

print("\n===== DIAGNOSIS OUTPUT =====")
print(diagnosis_output)