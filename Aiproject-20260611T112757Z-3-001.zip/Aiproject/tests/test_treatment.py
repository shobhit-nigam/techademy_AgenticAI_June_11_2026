import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from langchain_agents import (
    parallel_workflow,
    run_diagnosis_agent,
    run_risk_agent,
    run_treatment_agent
)

from tools import calculate_risk_score


inputs = {
    "patient_id": "P001",
    "patient_complaint": "I have chest pain, sweating, and shortness of breath."
}

parallel_result = parallel_workflow.invoke(inputs)

triage_output = parallel_result["triage"]
history_output = parallel_result["history"]

diagnosis_output = run_diagnosis_agent(
    patient_complaint=inputs["patient_complaint"],
    triage_output=triage_output,
    history_output=history_output
)

risk_data = calculate_risk_score(
    age=62,
    chest_pain=True,
    sweating=True,
    shortness_of_breath=True,
    diabetes=True,
    hypertension=True
)

risk_output = run_risk_agent(
    patient_complaint=inputs["patient_complaint"],
    triage_output=triage_output,
    history_output=history_output,
    diagnosis_output=diagnosis_output,
    risk_data=risk_data
)

treatment_output = run_treatment_agent(
    patient_complaint=inputs["patient_complaint"],
    triage_output=triage_output,
    history_output=history_output,
    diagnosis_output=diagnosis_output,
    risk_output=risk_output
)

print("===== TREATMENT PLANNING OUTPUT =====")
print(treatment_output) 