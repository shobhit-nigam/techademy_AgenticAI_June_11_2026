import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from langchain_agents import parallel_workflow


result = parallel_workflow.invoke(
    {
        "patient_id": "P001",
        "patient_complaint":
        "I have chest pain, sweating, and shortness of breath."
    }
)

print(result)