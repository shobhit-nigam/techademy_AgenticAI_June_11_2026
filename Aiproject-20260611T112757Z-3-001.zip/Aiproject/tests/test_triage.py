import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_agents import run_triage_agent

result = run_triage_agent(
    "I have chest pain, sweating, and shortness of breath."
)

print(result)