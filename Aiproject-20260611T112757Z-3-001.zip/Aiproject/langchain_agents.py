from langchain_core.runnables import RunnableParallel
from dotenv import load_dotenv
load_dotenv()

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


llm = ChatOpenAI(
    model="gpt-4.1-mini",
    temperature=0
)

parser = StrOutputParser()


triage_prompt = ChatPromptTemplate.from_template("""
You are an Emergency Room Triage Nurse Agent.

Patient Complaint:
{patient_complaint}

Your job:

1. Identify symptoms
2. Identify emergency warning signs
3. Assign urgency level:
   - Low
   - Medium
   - High
   - Critical

4. Recommend next action

Do NOT provide diagnosis.

Format:

Symptoms:
Warning Signs:
Urgency Level:
Recommended Action:
""")

triage_chain = triage_prompt | llm | parser

def run_triage_agent(patient_complaint):

    result = triage_chain.invoke({
        "patient_complaint": patient_complaint
    })

    return result





from tools import get_patient_history, calculate_risk_score

history_prompt = ChatPromptTemplate.from_template("""
You are a Medical History Agent.

Patient ID:
{patient_id}

Patient History:
{patient_history}

Your job:
1. Summarize patient demographics.
2. Summarize existing conditions.
3. Highlight allergies.
4. Highlight current medications.
5. Mention insurance plan.
6. Identify emergency risk factors.

Keep the output structured.
""")


history_chain = history_prompt | llm | parser


def run_history_agent(patient_id):
    patient_history = get_patient_history(patient_id)

    result = history_chain.invoke({
        "patient_id": patient_id,
        "patient_history": patient_history
    })

    return result


parallel_workflow = RunnableParallel(
    triage=lambda x: run_triage_agent(
        x["patient_complaint"]
    ),

    history=lambda x: run_history_agent(
        x["patient_id"]
    )
)


diagnosis_prompt = ChatPromptTemplate.from_template("""
You are an Emergency Diagnosis Support Agent.

Patient Complaint:
{patient_complaint}

Triage Agent Output:
{triage_output}

Medical History Agent Output:
{history_output}

Your job:
1. Suggest 2 to 4 possible conditions.
2. Explain why each condition is possible.
3. Mark the most urgent possibility.
4. Do not give a final diagnosis.
5. Recommend doctor confirmation.

Keep the output structured.
""")


diagnosis_chain = diagnosis_prompt | llm | parser


def run_diagnosis_agent(patient_complaint, triage_output, history_output):

    result = diagnosis_chain.invoke({
        "patient_complaint": patient_complaint,
        "triage_output": triage_output,
        "history_output": history_output
    })

    return result



risk_prompt = ChatPromptTemplate.from_template("""
You are an Emergency Risk Assessment Agent.

Patient Complaint:
{patient_complaint}

Triage Output:
{triage_output}

Medical History Output:
{history_output}

Diagnosis Output:
{diagnosis_output}

Numeric Risk Data:
{risk_data}

Your job:
1. Explain the risk score.
2. Classify the emergency level.
3. Identify escalation needs.
4. Recommend whether immediate doctor intervention is required.

Keep the output structured.
""")


risk_chain = risk_prompt | llm | parser


def run_risk_agent(
    patient_complaint,
    triage_output,
    history_output,
    diagnosis_output,
    risk_data
):

    result = risk_chain.invoke({
        "patient_complaint": patient_complaint,
        "triage_output": triage_output,
        "history_output": history_output,
        "diagnosis_output": diagnosis_output,
        "risk_data": risk_data
    })

    return result


treatment_prompt = ChatPromptTemplate.from_template("""
You are an Emergency Treatment Planning Agent.

Patient Complaint:
{patient_complaint}

Triage Output:
{triage_output}

Medical History Output:
{history_output}

Diagnosis Output:
{diagnosis_output}

Risk Assessment Output:
{risk_output}

Your job:
1. Recommend immediate ER actions.
2. Suggest tests such as ECG, blood tests, oxygen support, imaging, or specialist consult.
3. Mention allergy and medication cautions.
4. Do not prescribe exact medication dosages.
5. Always require doctor approval.

Keep the output structured and practical.
""")


treatment_chain = treatment_prompt | llm | parser


def run_treatment_agent(
    patient_complaint,
    triage_output,
    history_output,
    diagnosis_output,
    risk_output
):

    result = treatment_chain.invoke({
        "patient_complaint": patient_complaint,
        "triage_output": triage_output,
        "history_output": history_output,
        "diagnosis_output": diagnosis_output,
        "risk_output": risk_output
    })

    return result



insurance_prompt = ChatPromptTemplate.from_template("""
You are a Hospital Insurance Verification Agent.

Patient ID:
{patient_id}

Patient History:
{patient_history}

Treatment Plan:
{treatment_output}

Your job:
1. Identify the insurance plan.
2. State likely emergency coverage.
3. Mention any billing or approval notes.
4. Clearly mention that emergency care should not be delayed because of insurance.
5. Keep the output short and practical.

Do not reject or delay emergency treatment.
""")


insurance_chain = insurance_prompt | llm | parser


def run_insurance_agent(
    patient_id,
    patient_history,
    treatment_output
):

    result = insurance_chain.invoke({
        "patient_id": patient_id,
        "patient_history": patient_history,
        "treatment_output": treatment_output
    })

    return result



doctor_prompt = ChatPromptTemplate.from_template("""
You are the Human Doctor Approval Agent.

Review the complete emergency case.

Patient Complaint:
{patient_complaint}

Triage Output:
{triage_output}

Medical History Output:
{history_output}

Diagnosis Output:
{diagnosis_output}

Risk Assessment Output:
{risk_output}

Treatment Plan:
{treatment_output}

Insurance Output:
{insurance_output}

Your job:
1. Approve, modify, or reject the AI-generated treatment plan.
2. Clearly explain your decision.
3. Prioritize patient safety.
4. Mention that final medical decisions belong to licensed clinicians.
5. Keep the output structured and decisive.

Format:
Decision:
Reason:
Required Actions:
Doctor Note:
""")


doctor_chain = doctor_prompt | llm | parser


def run_doctor_agent(
    patient_complaint,
    triage_output,
    history_output,
    diagnosis_output,
    risk_output,
    treatment_output,
    insurance_output
):

    result = doctor_chain.invoke({
        "patient_complaint": patient_complaint,
        "triage_output": triage_output,
        "history_output": history_output,
        "diagnosis_output": diagnosis_output,
        "risk_output": risk_output,
        "treatment_output": treatment_output,
        "insurance_output": insurance_output
    })

    return result


communication_prompt = ChatPromptTemplate.from_template("""
You are a Patient Communication Agent.

Patient Complaint:
{patient_complaint}

Doctor Decision:
{doctor_output}

Treatment Plan:
{treatment_output}

Risk Assessment:
{risk_output}

Your job:
1. Explain the doctor's decision to the patient in simple language.
2. Avoid medical jargon.
3. Keep the tone calm, reassuring, and clear.
4. Explain what will happen next.
5. Mention that the care team will continue monitoring the patient.

Keep the response patient-friendly and concise.
""")


communication_chain = communication_prompt | llm | parser


def run_patient_communication_agent(
    patient_complaint,
    doctor_output,
    treatment_output,
    risk_output
):

    result = communication_chain.invoke({
        "patient_complaint": patient_complaint,
        "doctor_output": doctor_output,
        "treatment_output": treatment_output,
        "risk_output": risk_output
    })

    return result