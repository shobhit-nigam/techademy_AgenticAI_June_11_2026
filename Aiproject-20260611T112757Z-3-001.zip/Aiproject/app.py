from dotenv import load_dotenv
load_dotenv()

import streamlit as st

from langchain_agents import (
    parallel_workflow,
    run_diagnosis_agent,
    run_risk_agent,
    run_treatment_agent,
    run_insurance_agent,
    run_doctor_agent,
    run_patient_communication_agent
)

from tools import calculate_risk_score, get_patient_history


st.set_page_config(
    page_title="AI Hospital - LangChain",
    layout="wide"
)

st.title("🏥 AI Hospital")
st.subheader("Multi-Agent Emergency Room using LangChain + OpenAI")

st.info(
    "This version demonstrates multiple agents working in tandem. "
    "Triage Agent and Medical History Agent run in parallel using LangChain."
)

patient_id = st.selectbox(
    "Select Patient ID",
    ["P001", "P002", "P003", "P004", "P005"]
)

patient_complaint = st.text_area(
    "Patient Complaint",
    "I have chest pain, sweating, and shortness of breath."
)

if st.button("Run AI Hospital Agents"):

    with st.spinner("Running Triage Agent and Medical History Agent in parallel..."):

        inputs = {
            "patient_id": patient_id,
            "patient_complaint": patient_complaint
        }

        parallel_result = parallel_workflow.invoke(inputs)

        triage_output = parallel_result["triage"]
        history_output = parallel_result["history"]

    st.markdown("## Parallel Agent Execution")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("### 1A. Triage Nurse Agent")
        st.write(triage_output)

    with col2:
        st.markdown("### 1B. Medical History Agent")
        st.write(history_output)

    diagnosis_output = run_diagnosis_agent(
        patient_complaint=patient_complaint,
        triage_output=triage_output,
        history_output=history_output
    )

    st.markdown("## 2. Diagnosis Agent Output")
    st.write(diagnosis_output)

    risk_data = calculate_risk_score(
        age=62,
        chest_pain=True,
        sweating=True,
        shortness_of_breath=True,
        diabetes=True,
        hypertension=True
    )

    risk_output = run_risk_agent(
        patient_complaint=patient_complaint,
        triage_output=triage_output,
        history_output=history_output,
        diagnosis_output=diagnosis_output,
        risk_data=risk_data
    )

    st.markdown("## 3. Risk Assessment Agent Output")
    st.write(risk_output)

    treatment_output = run_treatment_agent(
        patient_complaint=patient_complaint,
        triage_output=triage_output,
        history_output=history_output,
        diagnosis_output=diagnosis_output,
        risk_output=risk_output
    )

    st.markdown("## 4. Treatment Planning Agent Output")
    st.write(treatment_output)

    patient_history = get_patient_history(patient_id)

    insurance_output = run_insurance_agent(
        patient_id=patient_id,
        patient_history=patient_history,
        treatment_output=treatment_output
    )

    st.markdown("## 5. Insurance Agent Output")
    st.write(insurance_output)

    doctor_output = run_doctor_agent(
        patient_complaint=patient_complaint,
        triage_output=triage_output,
        history_output=history_output,
        diagnosis_output=diagnosis_output,
        risk_output=risk_output,
        treatment_output=treatment_output,
        insurance_output=insurance_output
    )

    st.markdown("## 6. Doctor Approval Agent Output")
    st.write(doctor_output)

    communication_output = run_patient_communication_agent(
        patient_complaint=patient_complaint,
        doctor_output=doctor_output,
        treatment_output=treatment_output,
        risk_output=risk_output
    )

    st.markdown("## 7. Patient Communication Agent Output")
    st.success(communication_output)