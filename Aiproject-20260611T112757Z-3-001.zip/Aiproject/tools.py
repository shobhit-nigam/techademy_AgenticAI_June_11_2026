import pandas as pd


def get_patient_history(patient_id):
    df = pd.read_csv("patient_data/patients.csv")

    patient = df[df["patient_id"] == patient_id]

    if patient.empty:
        return "Patient record not found."

    return patient.to_dict(orient="records")[0]



def calculate_risk_score(age, chest_pain, sweating, shortness_of_breath, diabetes, hypertension):
    score = 0

    if age >= 60:
        score += 20
    if chest_pain:
        score += 25
    if sweating:
        score += 15
    if shortness_of_breath:
        score += 20
    if diabetes:
        score += 10
    if hypertension:
        score += 10

    if score >= 80:
        level = "Critical"
    elif score >= 60:
        level = "High"
    elif score >= 30:
        level = "Medium"
    else:
        level = "Low"

    return {
        "risk_score": score,
        "risk_level": level
    }